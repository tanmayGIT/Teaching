//
//  RequeteManager.h
//  projetLP3
//
//  Created by Guillaume Chiron on 03/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

// RequeteManager.h
#import <Foundation/Foundation.h>

@protocol RequeteManagerDelegate <NSObject>
@required
    - (void)requeteManagerResponse:(NSString *) htmlsource;
@end

@interface RequeteManager : NSObject {
    id <RequeteManagerDelegate> delegate;
    NSMutableData * receivedData;
}

@property (retain) id delegate;
-(void)lancerRequete:(NSString *)url;

@end
