//
//  RequeteManager.m
//  projetLP3
//
//  Created by Guillaume Chiron on 03/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

// --------- RequeteManager.m ----------------
#import "RequeteManager.h"

@implementation RequeteManager
@synthesize delegate;

-(void)lancerRequete:(NSString *)url {
    
    NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:url]
                                              cachePolicy:NSURLRequestUseProtocolCachePolicy
                                          timeoutInterval:60.0];
    
    NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
    
    if (theConnection) {
        receivedData = [[NSMutableData data] retain];
    } else {
        NSLog(@"Erreur de connexion");
    } 
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [receivedData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    [connection release];
    [receivedData release];
    NSLog(@"Erreur");
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSString * receivedString = [[NSString alloc] initWithData:receivedData encoding:NSASCIIStringEncoding];
    [[self delegate] requeteManagerResponse:receivedString];
    [connection release];
    [receivedData release];
}
@end
